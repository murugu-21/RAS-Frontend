import React, { Component } from "react";

class Manager extends Component {
  render() {
    return <h1>Clerk</h1>;
  }
}

export default Manager;
